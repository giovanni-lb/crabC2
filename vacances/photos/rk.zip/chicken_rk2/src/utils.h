#pragma once

bool check_password(const char *input);
