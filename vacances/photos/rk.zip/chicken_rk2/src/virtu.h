#pragma once

int is_running_in_vm(void);
