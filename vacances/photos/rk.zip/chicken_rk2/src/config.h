#pragma once

int init_config(void);
