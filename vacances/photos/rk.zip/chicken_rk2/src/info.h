#pragma once

char *get_hostname(void);
char *get_rdn(void);
