#pragma once
void relink_module(struct module *mod);
void unlink_module(struct module *mod);
